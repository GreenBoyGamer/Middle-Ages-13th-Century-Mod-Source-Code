package net.minecraft.client;

import com.mojang.blaze3d.GraphicsWorkarounds;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.serialization.Codec;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.server.level.ParticleStatus;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.Util;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public enum GraphicsPreset implements StringRepresentable {
    FAST("fast", "options.graphics.fast"),
    FANCY("fancy", "options.graphics.fancy"),
    FABULOUS("fabulous", "options.graphics.fabulous"),
    CUSTOM("custom", "options.graphics.custom");

    private final String serializedName;
    private final String key;
    public static final Codec<GraphicsPreset> CODEC = StringRepresentable.fromEnum(GraphicsPreset::values);

    private GraphicsPreset(String serializedName, String key) {
        this.serializedName = serializedName;
        this.key = key;
    }

    @Override
    public String getSerializedName() {
        return this.serializedName;
    }

    public String getKey() {
        return this.key;
    }

    public void apply(Minecraft minecraft) {
        OptionsSubScreen screen = minecraft.screen instanceof OptionsSubScreen ? (OptionsSubScreen)minecraft.screen : null;
        GpuDevice device = RenderSystem.getDevice();
        switch (this) {
            case FAST: {
                int viewDistance = 8;
                this.set(screen, minecraft.options.biomeBlendRadius(), 1);
                this.set(screen, minecraft.options.renderDistance(), 8);
                this.set(screen, minecraft.options.prioritizeChunkUpdates(), PrioritizeChunkUpdates.NONE);
                this.set(screen, minecraft.options.simulationDistance(), 6);
                this.set(screen, minecraft.options.ambientOcclusion(), false);
                this.set(screen, minecraft.options.cloudStatus(), CloudStatus.FAST);
                this.set(screen, minecraft.options.particles(), ParticleStatus.DECREASED);
                this.set(screen, minecraft.options.mipmapLevels(), 2);
                this.set(screen, minecraft.options.entityShadows(), false);
                this.set(screen, minecraft.options.entityDistanceScaling(), 0.75);
                this.set(screen, minecraft.options.menuBackgroundBlurriness(), 2);
                this.set(screen, minecraft.options.cloudRange(), 32);
                this.set(screen, minecraft.options.cutoutLeaves(), false);
                this.set(screen, minecraft.options.improvedTransparency(), false);
                this.set(screen, minecraft.options.weatherRadius(), 5);
                this.set(screen, minecraft.options.maxAnisotropyBit(), 1);
                this.set(screen, minecraft.options.textureFiltering(), TextureFilteringMethod.NONE);
                break;
            }
            case FANCY: {
                int viewDistance = 16;
                this.set(screen, minecraft.options.biomeBlendRadius(), 2);
                this.set(screen, minecraft.options.renderDistance(), 16);
                this.set(screen, minecraft.options.prioritizeChunkUpdates(), PrioritizeChunkUpdates.PLAYER_AFFECTED);
                this.set(screen, minecraft.options.simulationDistance(), 12);
                this.set(screen, minecraft.options.ambientOcclusion(), true);
                this.set(screen, minecraft.options.cloudStatus(), CloudStatus.FANCY);
                this.set(screen, minecraft.options.particles(), ParticleStatus.ALL);
                this.set(screen, minecraft.options.mipmapLevels(), 4);
                this.set(screen, minecraft.options.entityShadows(), true);
                this.set(screen, minecraft.options.entityDistanceScaling(), 1.0);
                this.set(screen, minecraft.options.menuBackgroundBlurriness(), 5);
                this.set(screen, minecraft.options.cloudRange(), 64);
                this.set(screen, minecraft.options.cutoutLeaves(), true);
                this.set(screen, minecraft.options.improvedTransparency(), false);
                this.set(screen, minecraft.options.weatherRadius(), 10);
                this.set(screen, minecraft.options.maxAnisotropyBit(), 1);
                this.set(screen, minecraft.options.textureFiltering(), TextureFilteringMethod.RGSS);
                break;
            }
            case FABULOUS: {
                int viewDistance = 32;
                this.set(screen, minecraft.options.biomeBlendRadius(), 2);
                this.set(screen, minecraft.options.renderDistance(), 32);
                this.set(screen, minecraft.options.prioritizeChunkUpdates(), PrioritizeChunkUpdates.PLAYER_AFFECTED);
                this.set(screen, minecraft.options.simulationDistance(), 12);
                this.set(screen, minecraft.options.ambientOcclusion(), true);
                this.set(screen, minecraft.options.cloudStatus(), CloudStatus.FANCY);
                this.set(screen, minecraft.options.particles(), ParticleStatus.ALL);
                this.set(screen, minecraft.options.mipmapLevels(), 4);
                this.set(screen, minecraft.options.entityShadows(), true);
                this.set(screen, minecraft.options.entityDistanceScaling(), 1.25);
                this.set(screen, minecraft.options.menuBackgroundBlurriness(), 5);
                this.set(screen, minecraft.options.cloudRange(), 128);
                this.set(screen, minecraft.options.cutoutLeaves(), true);
                this.set(screen, minecraft.options.improvedTransparency(), Util.getPlatform() != Util.OS.OSX);
                this.set(screen, minecraft.options.weatherRadius(), 10);
                this.set(screen, minecraft.options.maxAnisotropyBit(), 2);
                if (GraphicsWorkarounds.get(device).isAmd()) {
                    this.set(screen, minecraft.options.textureFiltering(), TextureFilteringMethod.RGSS);
                } else {
                    this.set(screen, minecraft.options.textureFiltering(), TextureFilteringMethod.ANISOTROPIC);
                }
            }
        }
    }

    <T> void set(@Nullable OptionsSubScreen screen, OptionInstance<T> option, T value) {
        if (option.get() != value) {
            option.set(value);
            if (screen != null) {
                screen.resetOption(option);
            }
        }
    }
}
