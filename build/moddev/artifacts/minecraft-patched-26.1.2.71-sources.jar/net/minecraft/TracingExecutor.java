package net.minecraft;

import com.mojang.jtracy.TracyClient;
import com.mojang.jtracy.Zone;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public record TracingExecutor(ExecutorService service) implements Executor {
    public Executor forName(String name) {
        if (SharedConstants.IS_RUNNING_IN_IDE) {
            return command -> this.service.execute(() -> {
                Thread thread = Thread.currentThread();
                String oldName = thread.getName();
                thread.setName(name);

                try (Zone ignored = TracyClient.beginZone(name, SharedConstants.IS_RUNNING_IN_IDE)) {
                    command.run();
                } finally {
                    thread.setName(oldName);
                }
            });
        } else {
            return (Executor)(TracyClient.isAvailable() ? (Executor)command -> this.service.execute(() -> {
                try (Zone ignored = TracyClient.beginZone(name, SharedConstants.IS_RUNNING_IN_IDE)) {
                    command.run();
                }
            }) : this.service);
        }
    }

    @Override
    public void execute(Runnable command) {
        this.service.execute(wrapUnnamed(command));
    }

    public void shutdownAndAwait(long timeout, TimeUnit unit) {
        this.service.shutdown();

        boolean terminated;
        try {
            terminated = this.service.awaitTermination(timeout, unit);
        } catch (InterruptedException var6) {
            terminated = false;
        }

        if (!terminated) {
            this.service.shutdownNow();
        }
    }

    private static Runnable wrapUnnamed(Runnable command) {
        return !TracyClient.isAvailable() ? command : () -> {
            try (Zone ignored = TracyClient.beginZone("task", SharedConstants.IS_RUNNING_IN_IDE)) {
                command.run();
            }
        };
    }
}
